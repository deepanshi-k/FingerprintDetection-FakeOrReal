import cv2
import matplotlib.pyplot as plt
# %matplotlib inline

#reading image
img1 = cv2.imread('1.bmp')
gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
print(gray1.shape)
# #keypoints
# sift = cv2.xfeatures2d.SIFT_create()
# keypoints_1, descriptors_1 = sift.detectAndCompute(img1,None)
#
# img_1 = cv2.drawKeypoints(gray1,keypoints_1,img1)
# print(len(descriptors_1),len(keypoints_1))

rows,cols=gray1.shape
matrix = cv2.getRotationMatrix2D((rows/2,cols/2),75,1)
new_img=cv2.warpAffine(img1,matrix,(cols,rows))
cv2.imwrite('1_tilted.jpg',new_img)


# plt.imshow(img_1)
# plt.show()
# plt.imshow(img1)
plt.imshow(new_img)
plt.show()




