import numpy as np
import cv2
from matplotlib import pyplot as plt

img_1 = cv2.imread('1.jpg')
gray1 = cv2.cvtColor(img_1, cv2.COLOR_BGR2GRAY)

img_2 = cv2.imread('1_tilted.jpg')
gray2 = cv2.cvtColor(img_2, cv2.COLOR_BGR2GRAY)

# Initiate FAST detector
star = cv2.xfeatures2d.StarDetector_create()
# Initiate BRIEF extractor
brief = cv2.xfeatures2d.BriefDescriptorExtractor_create()
# find the keypoints with STAR
kp1 = star.detect(gray1,None)
kp2 = star.detect(gray2,None)
# compute the descriptors with BRIEF
kp1, des1 = brief.compute(gray1, kp1)
kp1, des2 = brief.compute(gray1, kp1)
print( des1.shape )
print( des2.shape )


bf = cv2.BFMatcher(cv2.NORM_L1, crossCheck=True)

matches = bf.match(des1,des2)
matches = sorted(matches, key = lambda x:x.distance)

img3 = cv2.drawMatches(gray1, kp1, gray2, kp2, matches[:100], gray2, flags=2)

plt.imshow(img3)
plt.show()
