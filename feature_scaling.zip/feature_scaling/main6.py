import numpy as np
import cv2
from matplotlib import pyplot as plt
imgname = "thumb.dib"          # query image (large scene)
imgname2 = "thumb.dib"   # train image (small object)

## Create SIFT object
sift = cv2.xfeatures2d.SIFT_create()

## Create flann matcher
FLANN_INDEX_KDTREE = 1  # bug: flann enums are missing
flann_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 5)
#matcher = cv2.FlannBasedMatcher_create()
matcher = cv2.FlannBasedMatcher(flann_params, {})

## Detect and compute
img1 = cv2.imread(imgname)
gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
kpts1, descs1 = sift.detectAndCompute(gray1,None)

## As up
img2 = cv2.imread(imgname2)
gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
kpts2, descs2 = sift.detectAndCompute(gray2,None)

bf = cv2.BFMatcher()
matches = bf.knnMatch(descs1, descs2, k=2)

good = []
for m,n in matches:
    if m.distance < 0.3 * n.distance:
        good.append(m)

# Featured matched keypoints from images 1 and 2
pts1 = np.float32([kpts1[m.queryIdx].pt for m in good])
pts2 = np.float32([kpts2[m.trainIdx].pt for m in good])

# Convert x, y coordinates into complex numbers
# so that the distances are much easier to compute
z1 = np.array([[complex(c[0],c[1]) for c in pts1]])
z2 = np.array([[complex(c[0],c[1]) for c in pts2]])

# Computes the intradistances between keypoints for each image
KP_dist1 = abs(z1.T - z1)
KP_dist2 = abs(z2.T - z2)

# Distance between featured matched keypoints
FM_dist = abs(z2 - z1)

img3 = cv2.drawMatchesKnn(img1, kpts1, img2, kpts2, good, flags=2, outImg=img2)

plt.imshow(img3), plt.show()